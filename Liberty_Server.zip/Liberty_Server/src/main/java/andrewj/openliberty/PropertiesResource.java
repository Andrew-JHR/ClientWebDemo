package andrewj.openliberty;

import java.util.Properties;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;

import jakarta.json.Json;
import jakarta.json.JsonObject;
import jakarta.json.JsonWriter;
import jakarta.json.JsonWriterFactory; 
import jakarta.json.stream.JsonGenerator;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

// tag::path[]
@Path("/")
// end::path[]
public class PropertiesResource {
    
    @Path("properties")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Properties getProperties() {
        return System.getProperties();
    }

    @Path("data")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response cosumeData(JsonObject jo) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
        LocalDateTime now = LocalDateTime.now(); 
        System.out.println(dtf.format(now) + " Data Received: ");

        Map < String, Boolean > config = new HashMap < String, Boolean > ();
        config.put(JsonGenerator.PRETTY_PRINTING, true);
        
        JsonWriterFactory jwf = Json.createWriterFactory(config);
        StringWriter sw = new StringWriter();

        try (JsonWriter jsonWriter = jwf.createWriter(sw)) {
             jsonWriter.writeObject(jo);
             System.out.println(sw.toString());
        }
                
        return Response.ok(jo).build();
    }
}


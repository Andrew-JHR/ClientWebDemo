package andrewj.openliberty;

import jakarta.ws.rs.core.Application;
import jakarta.ws.rs.ApplicationPath;

// tag::applicationPath[]
@ApplicationPath("/")
// end::applicationPath[]
// tag::RestApplication[]
public class RestApplication extends Application {

}
// end::RestApplication[]

1. pom.xml is used by Apache Maven. You must fist install Maven from Maven: https://maven.apache.org/

2. From the command line, issue 'mvn liberty:dev' to execute the Liberty Server.

3. mvn will create /target folder, once started, the Liberty server is executed under /target/liberty/wlp/user/servers/defaultServer/ .

4. To enable HTTP SSL (https://), you must place the file 'server-cert.p12' -- named as whatever you like -- in 
   /src/resources/security/. Once executed, Maven will copy it to /target/iberty/wlp/user/servers/defaultServer/resources/security/ .

5. In the file: /target/iberty/wlp/user/servers/defaultServer/server.env, the auto-generated line: 'keystore_password=...' must be removed and
   save 'server.env' to let the SSL setting to take effect.

6. The password of server-cert.p12 must be provided in /src/main/libery/config/server.xml. 

7. In this example, JDKv11 is used. I installed openjdk11 from https://www.openlogic.com/openjdk-downloads. 
   On my Windows, the default JAVA is v1.8 (aka. JAVA8), but I also installed v11, and set the system variable: JAVA_HOME to be
   d:\Program Files\java\jdk11.0.17

8. In pom.xml:
    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
        <maven.compiler.source>11</maven.compiler.source>
        <maven.compiler.target>11</maven.compiler.target>
   The '11' above stands for jdkv11.
   It could be workable if '11' was changed to be '8' while using JAVA8 instead, but I have not tried.

9. /src/main/test is for Unit Test only, sort of Optional. Also in pom.xml,those defined between <dependencies> </dependencies>  and 
   those between <dependency></dependency> under <!-- For tests --> are also Optional.

10. What Maven has created in /target folder : /target/liberty/wlp/README.TXT is almost identical to counterpart of z/OS 2.4 Liberty:
    /usr/lpp/liberty_zos/22.0.0.9/README.TXT on the mainframe. The version of OpenLiberty is 23.0.0.6

Andrew Jan  